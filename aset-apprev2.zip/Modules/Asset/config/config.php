<?php

return [
    'name' => 'Asset',
];
