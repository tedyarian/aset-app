<?php

namespace Modules\Asset\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;

class SettingController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        // Mengambil daftar pengguna untuk menu Manajemen Pengguna (Users & Roles)
        $users = User::all();
        return view('asset::settings.index', compact('users'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('asset::create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function storeUser(Request $request) {
        
        // 1. Validasi input dari form
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|min:6',
            'role' => 'required|string', // <-- Tambahkan validasi rol

        ]);

        // 2. Simpan data ke tabel users
        \App\Models\User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => bcrypt($request->password),
            'role' => $request->role, // <-- Simpan role
        ]);

        // 3. Kembali ke halaman pengaturan dengan pesan sukses
        return redirect()->route('settings.index')->with('success', 'Pengguna baru berhasil ditambahkan!');
    }

    /**
     * Show the specified resource.
     */
    public function show($id)
    {
        return view('asset::show');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function editUser($id)
    {
        $user = \App\Models\User::findOrFail($id);
        $users = \App\Models\User::all();
        
        // Kita bisa mengirim kembali ke index dengan membawa data user yang akan diedit
        return view('asset::settings.index', compact('users', 'user'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function updateUser(Request $request, $id) {
        $user = \App\Models\User::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email,' . $id,
            'role' => 'required|string',
            'password' => 'nullable|min:6', // Password opsional saat edit
        ]);

        $user->name = $request->name;
        $user->email = $request->email;
        $user->role = $request->role;

        if ($request->filled('password')) {
            $user->password = bcrypt($request->password);
        }

        $user->save();

        return redirect()->route('settings.index')->with('success', 'Data pengguna berhasil diperbarui!');
    }

    // Menghapus pengguna
    public function deleteUser($id)
    {
        $user = \App\Models\User::findOrFail($id);
        $user->delete();

        return redirect()->route('settings.index')->with('success', 'Pengguna berhasil dihapus!');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id) {}
}
