<?php

namespace Modules\Asset\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\Asset\Models\Department;
use Modules\Asset\Models\Location;
use Modules\Asset\Models\Room;


class MasterDataController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $departments = Department::all();
        $locations = Location::all();
        $rooms = Room::all(); // <-- Ambil data ruangan
        
        return view('asset::master.index', compact('departments', 'locations','rooms'));
    }

    // Menyimpan Departemen Baru
    public function storeDepartment(Request $request)
    {
        $validated = $request->validate([
        'name' => 'required|string|max:255'
    ]);

    // Gunakan data yang sudah divalidasi, otomatis token _token diabaikan
    Department::create($validated);

    return redirect()->route('master.index')->with('success', 'Departemen berhasil ditambahkan!');  }

    // Menyimpan Lokasi Baru
    public function storeLocation(Request $request)
    {
        $validated = $request->validate([
        'name' => 'required|string|max:255'
    ]);

    Location::create($validated);

    return redirect()->route('master.index')->with('success', 'Lokasi berhasil ditambahkan!');
    }

    // Hapus Departemen
    public function destroyDepartment($id)
    {
        Department::findOrFail($id)->delete();
        return redirect()->route('master.index')->with('success', 'Departemen berhasil dihapus!');
    }

    // Hapus Lokasi
    public function destroyLocation($id)
    {
        Location::findOrFail($id)->delete();
        return redirect()->route('master.index')->with('success', 'Lokasi berhasil dihapus!');
    }

    // Menyimpan Ruangan Baru
    public function storeRoom(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255'
        ]);

        Room::create($validated);

        return redirect()->route('master.index')->with('success', 'Ruangan berhasil ditambahkan!');
    }

    // Hapus Ruangan
    public function destroyRoom($id)
    {
        Room::findOrFail($id)->delete();
        return redirect()->route('master.index')->with('success', 'Ruangan berhasil dihapus!');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id) {}
}
