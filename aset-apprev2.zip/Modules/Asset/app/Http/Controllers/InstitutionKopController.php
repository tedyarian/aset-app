<?php

namespace Modules\Asset\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\Asset\Models\InstitutionKop;
use Illuminate\Support\Facades\Storage;

class InstitutionKopController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('asset::index');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('asset::create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request) {}

    /**
     * Show the specified resource.
     */
    public function show($id)
    {
        return view('asset::show');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        return view('asset::edit');
    }

    /**
     * Update the specified resource in storage.
     */
    
    public function update(Request $request)
    {
        // Ambil data pertama atau buat instance baru jika belum ada
        $kop = InstitutionKop::first() ?? new InstitutionKop();

        $data = $request->except(['logo', '_token', '_method']);

        if ($request->hasFile('logo')) {
            if ($kop->logo && Storage::disk('public')->exists($kop->logo)) {
                Storage::disk('public')->delete($kop->logo);
            }
            $data['logo'] = $request->file('logo')->store('kop-logos', 'public');
        }

        $kop->fill($data);
        $kop->save();

        return redirect()->back()->with('success', 'Master Template KOP berhasil diperbarui!');
    }


    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id) {}
}
