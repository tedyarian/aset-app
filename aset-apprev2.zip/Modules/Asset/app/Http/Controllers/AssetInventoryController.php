<?php

namespace Modules\Asset\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\Asset\Models\AssetItem;
use Modules\Asset\Models\Department;
use Modules\Asset\Models\Location;
use Modules\Asset\Models\Room;
use Modules\Asset\Services\AssetService; // Pastikan service di-import

class AssetInventoryController extends Controller
{

    protected $assetService;

    // Inject AssetService melalui constructor
    public function __construct(AssetService $assetService)
    {
        $this->assetService = $assetService;
    }

    // 1. Daftar Semua Aset
    public function index()
    {
        $assets = AssetItem::with(['department', 'location', 'room'])->latest()->get();
        return view('asset::inventory.index', compact('assets'));
    }

    // 2. Form Tambah Aset
    public function create(Request $request)
    {
        $departments = Department::all();
        $locations = Location::all();
        $rooms = Room::all();
        $bmnItems = \Modules\Asset\Models\BmnItem::all(); // Ambil data BMN

        // Ambil ID dari session terakhir atau request aktif untuk input massal
        $selectedDept = session('last_department_id') ?? $request->department_id;
        $selectedLoc = session('last_location_id') ?? $request->location_id;
        $selectedRoom = session('last_room_id') ?? $request->room_id;

        // Ambil daftar aset terbaru berdasarkan ruangan tersebut (misal 5 data terakhir)
        $recentAssets = [];
        if ($selectedRoom) {
            $recentAssets = AssetItem::where('room_id', $selectedRoom)
                ->latest()
                ->take(5)
                ->get();
        }

        return view('asset::inventory.create', compact(
            'departments', 'locations', 'rooms', 'bmnItems', 'recentAssets',
            'selectedDept', 'selectedLoc', 'selectedRoom'
        ));
    }

    // Simpan Aset Baru (Mendukung Input Satuan & Massal + Nomor Urut)
    public function store(Request $request)
    {
        $validated = $request->validate([
            'code'            => 'required|string',
            'name'            => 'required|string|max:255',
            'brand'           => 'nullable|string|max:255',
            'department_id'   => 'required|exists:departments,id',
            'location_id'     => 'required|exists:locations,id',
            'room_id'         => 'required|exists:rooms,id',
            'quantity'        => 'required|integer|min:1',
            'status'          => 'required|string',
            'pic'             => 'nullable|string|max:255',
            'image'           => 'nullable|image|mimes:jpeg,png,jpg,webp|max:2048',
            'notes'           => 'nullable|string|max:255',
            'price'           => 'nullable|numeric',
            'contract_number' => 'nullable|string|max:255',
        ]);

        // Simpan pilihan lokasi ke session untuk input massal berikutnya
        session([
            'last_department_id' => $validated['department_id'],
            'last_location_id'   => $validated['location_id'],
            'last_room_id'       => $validated['room_id'],
        ]);

        // Proses Simpan File Gambar (jika ada)
        $imagePath = null;
        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $filename = time() . '_' . $file->getClientOriginalName();
            $file->move(public_path('storage/assets'), $filename);
            $imagePath = 'storage/assets/' . $filename;
        }

        $qty = (int) $validated['quantity'];
        $baseCode = $validated['code']; // Contoh: "2.12.1.2" dari BMN

        // Lakukan looping sebanyak jumlah quantity yang diinput sekaligus simpan no_urut
        for ($i = 1; $i <= $qty; $i++) {
            $runningNumber = str_pad($i, 5, '0', STR_PAD_LEFT);
            
            $itemData = $validated;
            $itemData['code'] = "{$baseCode}.{$runningNumber}";
            $itemData['no_urut'] = $i; // Menyimpan nomor urut
            $itemData['quantity'] = 1; // Dipecah menjadi 1 per baris unik
            
            if ($imagePath) {
                $itemData['image'] = $imagePath;
            }

            AssetItem::create($itemData);
        }

        // Redirect berdasarkan tombol yang diklik
        if ($request->input('action') === 'save_and_add') {
            return redirect()->route('inventory.create')
                ->with('success', "Berhasil menyimpan {$qty} aset dengan penomoran otomatis!");
        }

        return redirect()->route('inventory.index')
            ->with('success', "Berhasil menyimpan {$qty} aset baru.");
    } // <--- PASTIKAN KURUNG KURAWAL PENUTUP INI ADA

    // 3. Detail Aset & Riwayat
    public function show($id)
    {
        $asset = AssetItem::with(['department', 'location', 'room','histories'])->findOrFail($id);
        return view('asset::inventory.show', compact('asset'));
    }

    // 4. Cetak Barcode / QR Code
    public function barcode($id)
    {
        $asset = AssetItem::findOrFail($id);
        return view('asset::inventory.barcode', compact('asset'));
    }

    public function edit($id)
    {
        $asset = AssetItem::findOrFail($id);
        $departments = \Modules\Asset\Models\Department::all();
        $locations = \Modules\Asset\Models\Location::all();
        $rooms = \Modules\Asset\Models\Room::all();

        return view('asset::inventory.edit', compact('asset', 'departments', 'locations', 'rooms'));
    }

        public function update(Request $request, $id) {
        $request->validate([
            'reason' => 'required|string|max:255', // Alasan wajib diisi saat edit
        ]);

        $this->assetService->updateAsset($id, $request->all());

        return redirect()->route('inventory.index')->with('success', 'Aset berhasil diperbarui dan riwayat perubahan dicatat.');
    }

    // Hapus Aset
    public function destroy($id)
    {
        AssetItem::findOrFail($id)->delete();
        return redirect()->route('inventory.index')->with('success', 'Aset berhasil dihapus dari sistem!');
    }

    public function searchBmnItems(Request $request)
    {
        $keyword = $request->get('q', '');

        $items = \Modules\Asset\Models\BmnItem::where('name', 'LIKE', "%{$keyword}%")
                    ->orWhere('code', 'LIKE', "%{$keyword}%")
                    ->limit(25)
                    ->get(['code', 'name']);

        return response()->json($items);
    }
}