<?php

namespace Modules\Asset\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Room extends Model
{
    use HasFactory;

    protected $table = 'rooms';
    protected $guarded = ['id'];

    public function department()
    {
        return $this->belongsTo(Department::class, 'location_id');
    }

    // Tambahkan kembali relasi location
    public function location()
    {
        return $this->belongsTo(Location::class, 'location_id'); // Sesuaikan foreign key jika menggunakan 'building_id'
    }

    // Jika ingin tetap menggunakan method location tapi mengambil dari kolom 'building'
    // Atau Anda bisa langsung memanggil $room->building di view.
}