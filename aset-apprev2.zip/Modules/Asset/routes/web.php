<?php

use Illuminate\Support\Facades\Route;
use Modules\Asset\Http\Controllers\AssetController;
use Modules\Asset\Http\Controllers\SettingController;
use Modules\Asset\Http\Controllers\AuthController;
use Modules\Asset\Http\Controllers\MasterDataController;
use Modules\Asset\Http\Controllers\AssetInventoryController;
use Modules\Asset\Http\Controllers\AssetTransactionController;
use Modules\Asset\Http\Controllers\AssetAuditController;
use Modules\Asset\Http\Controllers\AssetReportController;
use Modules\Asset\Http\Controllers\InstitutionKopController;

 // Rute Login (Guest)
        Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
        Route::post('/login', [AuthController::class, 'login']);


Route::middleware(['auth'])->group(function () {
    Route::get('/', [AssetController::class, 'index'])->name('dashboard');
    Route::get('/settings', [SettingController::class, 'index'])->name('settings.index');
    Route::post('/settings', [SettingController::class, 'update'])->name('settings.update');
    Route::post('/settings/users', [SettingController::class, 'storeUser'])->name('settings.users.store');

        // Tambahkan rute untuk Edit dan Hapus Pengguna
    Route::get('/settings/users/{id}/edit', [SettingController::class, 'editUser'])->name('settings.users.edit');
    Route::put('/settings/users/{id}', [SettingController::class, 'updateUser'])->name('settings.users.update');
    Route::delete('/settings/users/{id}', [SettingController::class, 'deleteUser'])->name('settings.users.destroy');

        // Rute Logout
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

    // Rute Master Data
    Route::get('/master-data', [MasterDataController::class, 'index'])->name('master.index');
    Route::post('/master-data/departments', [MasterDataController::class, 'storeDepartment'])->name('master.department.store');
    Route::delete('/master-data/departments/{id}', [MasterDataController::class, 'destroyDepartment'])->name('master.department.delete');
    
    Route::post('/master-data/locations', [MasterDataController::class, 'storeLocation'])->name('master.location.store');
    Route::delete('/master-data/locations/{id}', [MasterDataController::class, 'destroyLocation'])->name('master.location.delete');

    // Rute Master Ruangan
    Route::post('/master-data/rooms', [MasterDataController::class, 'storeRoom'])->name('master.room.store');
    Route::delete('/master-data/rooms/{id}', [MasterDataController::class, 'destroyRoom'])->name('master.room.delete');

    // Tambahkan route ini di dalam file rute Anda
    Route::put('/master/kop/update', [InstitutionKopController::class, 'update'])->name('master.kop.update');

    // Rute Manajemen Aset (Inventory)
    Route::get('/inventory', [AssetInventoryController::class, 'index'])->name('inventory.index');
    Route::get('/inventory/create', [AssetInventoryController::class, 'create'])->name('inventory.create');
    Route::post('/inventory', [AssetInventoryController::class, 'store'])->name('inventory.store');
    Route::get('/inventory/{id}', [AssetInventoryController::class, 'show'])->name('inventory.show');
    // --> TAMBAHKAN DUA RUTE INI DI SINI <--
    Route::get('/inventory/{id}/edit', [AssetInventoryController::class, 'edit'])->name('inventory.edit');
    Route::put('/inventory/{id}', [AssetInventoryController::class, 'update'])->name('inventory.update');
    
    Route::get('/inventory/{id}/barcode', [AssetInventoryController::class, 'barcode'])->name('inventory.barcode');
    Route::delete('/inventory/{id}', [AssetInventoryController::class, 'destroy'])->name('inventory.destroy');
    
    Route::get('/bmn-items/search', [AssetInventoryController::class, 'searchBmnItems'])->name('inventory.bmn-search');

    Route::prefix('transactions')->name('transactions.')->group(function () {
        // Index Utama Transaksi & Operasional
        Route::get('/', [AssetTransactionController::class, 'index'])->name('index');

        // 1. Mutasi / Perpindahan Aset
        Route::get('/mutation/create', [AssetTransactionController::class, 'createMutation'])->name('mutation.create');
        Route::post('/mutation', [AssetTransactionController::class, 'storeMutation'])->name('mutation.store');

        // 2. Peminjaman & Pengembalian (Check-out / Check-in)
        Route::get('/loan/create', [AssetTransactionController::class, 'createLoan'])->name('loan.create');
        Route::post('/loan', [AssetTransactionController::class, 'storeLoan'])->name('loan.store');
        Route::post('/loan/{loan}/return', [AssetTransactionController::class, 'returnLoan'])->name('loan.return');

        // 3. Perawatan & Perbaikan (Maintenance)
        Route::get('/maintenance/create', [AssetTransactionController::class, 'createMaintenance'])->name('maintenance.create');
        Route::post('/maintenance', [AssetTransactionController::class, 'storeMaintenance'])->name('maintenance.store');
    });

    Route::prefix('audits')->name('audits.')->group(function () {
            Route::get('/', [AssetAuditController::class, 'index'])->name('index');
            
            // 1. Sesi Audit
            Route::get('/create', [AssetAuditController::class, 'createSession'])->name('create');
            Route::post('/', [AssetAuditController::class, 'storeSession'])->name('store');
            Route::get('/{id}/scan', [AssetAuditController::class, 'scanPage'])->name('scan');
            Route::post('/{id}/scan', [AssetAuditController::class, 'processScan'])->name('process-scan');

            // 3. Laporan Selisih (Discrepancy)
            Route::get('/{id}/report', [AssetAuditController::class, 'discrepancyReport'])->name('report');
    });

    Route::prefix('reports')->name('reports.')->group(function () {
        Route::get('/', [AssetReportController::class, 'index'])->name('index');
        Route::get('/position', [AssetReportController::class, 'position'])->name('position');
        Route::get('/room', [AssetReportController::class, 'roomReport'])->name('room');
        Route::get('/depreciation', [AssetReportController::class, 'depreciation'])->name('depreciation');
        Route::get('/maintenance', [AssetReportController::class, 'maintenance'])->name('maintenance');
        Route::get('/disposal', [AssetReportController::class, 'disposal'])->name('disposal');
    });

});