

<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('header-title', 'Ringkasan Aset'); ?>

<?php $__env->startSection('content'); ?>

        <!-- Main Content Area -->
        <div class="flex-1 flex flex-col overflow-y-auto">
            <header class="bg-white shadow-sm h-16 flex items-center justify-between px-8">
                <h1 class="text-lg font-semibold text-slate-700">Dashboard Overview</h1>
                <div class="flex items-center space-x-4 text-sm text-slate-600">
                    <span>Notification</span>
                    <span class="font-medium text-slate-900">Admin User</span>
                </div>
            </header>

            <main class="p-8">
                <div class="mb-6">
                    <h2 class="text-2xl font-bold text-slate-800">Welcome back, Admin</h2>
                    <p class="text-sm text-slate-500">Berikut ringkasan statistik dan kondisi aset perusahaan hari ini.</p>
                </div>

                <!-- Metric Cards (Ringkasan Statistik) -->
                <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                    <div class="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                        <p class="text-sm text-slate-500">Total Jumlah Aset</p>
                        <h3 class="text-3xl font-bold text-slate-800 mt-2"><?php echo e($metrics['total'] ?? 0); ?></h3>
                        <span class="text-xs text-emerald-600 font-semibold">+3 baru minggu ini</span>
                    </div>
                    <div class="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                        <p class="text-sm text-slate-500">Total Keseluruhan Unit</p>
                        <h3 class="text-2xl font-bold text-slate-800 mt-2"><?php echo e(number_format($metrics['total_assets'] ?? 0)); ?> Unit</h3>
                        <span class="text-xs text-slate-400">Akumulasi jumlah fisik barang</span>
                    </div>
                    <div class="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                        <p class="text-sm text-slate-500">Aset Dalam Perbaikan</p>
                        <h3 class="text-3xl font-bold text-amber-600 mt-2"><?php echo e($metrics['maintenance']); ?></h3>
                        <span class="text-xs text-slate-400">Jadwal servis berkala</span>
                    </div>
                    <div class="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                        <p class="text-sm text-slate-500">Aset Aktif</p>
                        <h3 class="text-3xl font-bold text-blue-600 mt-2"><?php echo e($metrics['active']); ?></h3>
                        <span class="text-xs text-blue-600 font-semibold">Kondisi operasional</span>
                    </div>
                </div>

                <!-- Tabel Daftar Aset Terbaru -->
                <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                    <h3 class="text-lg font-bold text-slate-800 mb-4">Daftar Inventaris Aset Terbaru</h3>
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="border-b text-sm text-slate-500">
                                <th class="py-3">Kode Aset</th>
                                <th class="py-3">Nama Aset</th>
                                <th class="py-3">Type/Merk</th>
                                <th class="py-3">Lokasi</th>
                                <th class="py-3">Status</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100">
    <?php $__empty_1 = true; $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> <!-- Pastikan menggunakan "as $item" -->
        <tr>
            <td class="py-2.5 font-mono text-slate-600">
                <?php echo e($item->code ?? '-'); ?>

            </td>
            <td class="py-2.5">
                <span class="font-bold text-slate-700 block"><?php echo e($item->name); ?></span>
            </td>
            <td class="py-2.5 text-slate-600">
                <?php echo e($item->brand ?? '-'); ?>

            </td>
            <td class="py-2.5 text-slate-600">
                <?php echo e($item->location->name ?? '-'); ?> 
                <span class="block text-[11px] text-slate-400">(<?php echo e($item->room->name ?? '-'); ?>)</span>
            </td>
            <td class="py-2.5">
                <span class="px-2 py-0.5 rounded text-[10px] font-medium bg-emerald-100 text-emerald-700">
                    <?php echo e($item->status); ?>

                </span>
            </td>
            <!-- Kolom aksi atau tombol lainnya -->
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="6" class="py-4 text-center text-slate-400">Belum ada data inventaris aset.</td>
        </tr>
    <?php endif; ?>
</tbody>
                    </table>
                </div>
            </main>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('asset::layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/simbaram/aset-app/Modules/Asset/resources/views/index.blade.php ENDPATH**/ ?>