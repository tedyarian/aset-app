

<?php $__env->startSection('title', 'Laporan Posisi Aset'); ?>
<?php $__env->startSection('header-title', 'Laporan Posisi & Rekapitulasi Aset'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-5xl mx-auto space-y-6">
    
    <!-- KOP SURAT DINAMIS (Hanya muncul saat dicetak) -->
    <div class="hidden print:block mb-4 w-full">
        <?php echo $__env->make('asset::reports.partials.kop', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    <!-- Kontainer Utama Laporan -->
    <div class="bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-4 print:border-none print:shadow-none print:p-0 print:m-0">
        
        <!-- Header Bagian Atas: Judul di Kiri dan Tombol Cetak di Kanan -->
        <div class="flex justify-between items-center print:hidden">
            <h3 class="text-xs font-bold text-slate-700 uppercase">DAFTAR REKAPITULASI POSISI ASET</h3>           
            <button onclick="window.print()" class="px-3 py-1.5 bg-slate-100 text-slate-600 rounded-lg text-xs font-medium hover:bg-slate-200 transition">🖨️ Cetak / PDF</button>
        </div>

        <!-- Judul khusus untuk cetak -->
        <div class="hidden print:block text-center mb-4">
            <h3 class="text-sm font-bold text-black uppercase">DAFTAR REKAPITULASI POSISI ASET</h3>
        </div>

        <div class="w-full">
            <table class="w-full text-left text-xs border-collapse">
                <thead>
                    <tr class="border-b-2 border-slate-300 text-slate-700 bg-slate-50 print:bg-transparent">
                        <th class="py-2 px-2 border border-slate-300 text-center" style="width: 5%;">No</th>
                        <th class="py-2 px-2 border border-slate-300" style="width: 18%;">Kode BMN</th>
                        <th class="py-2 px-2 border border-slate-300" style="width: 25%;">Nama Aset</th>
                        <th class="py-2 px-2 border border-slate-300" style="width: 22%;">Lokasi / Ruangan</th>
                        <th class="py-2 px-2 border border-slate-300" style="width: 15%;">PIC</th>
                        <th class="py-2 px-2 border border-slate-300 text-center" style="width: 15%;">Kondisi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-200">
                    <?php $__empty_1 = true; $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="py-2 px-2 border border-slate-300 text-center"><?php echo e($index + 1); ?></td>
                            <td class="py-2 px-2 border border-slate-300 font-bold text-slate-700"><?php echo e($asset->asset_code ?? '-'); ?></td>
                            <td class="py-2 px-2 border border-slate-300 text-slate-600"><?php echo e($asset->name); ?></td>
                            <td class="py-2 px-2 border border-slate-300 text-slate-600"><?php echo e($asset->room->name ?? '-'); ?></td>
                            <td class="py-2 px-2 border border-slate-300 text-slate-600"><?php echo e($asset->pic ?? '-'); ?></td>
                            <td class="py-2 px-2 border border-slate-300 text-slate-600 font-semibold text-center whitespace-nowrap"><?php echo e($asset->status); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="py-4 text-center text-slate-400 border border-slate-300">Tidak ada data aset ditemukan.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- TANDA TANGAN / PENGETAHUAN (Hanya muncul saat dicetak) -->
    <div class="print-footer hidden print:flex justify-between pt-10 text-xs text-slate-800 w-full">
        <div class="text-center space-y-12">
            <p>Mengetahui,<br>Kepala Unit / Pengelola Barang</p>
            <p class="font-bold underline">( _________________________ )</p>
        </div>
        <div class="text-center space-y-12">
            <p>Bengkulu, <?php echo e(date('d F Y')); ?><br>Petugas / Pengurus Aset</p>
            <p class="font-bold underline">( Tedy Arian )</p>
        </div>
    </div>

    <div class="flex justify-end print:hidden">
        <a href="<?php echo e(route('reports.index')); ?>" class="px-4 py-2 bg-slate-100 text-slate-600 rounded-lg text-xs font-medium hover:bg-slate-200 transition">Kembali ke Menu Laporan</a>
    </div>
</div>

<!-- CSS KHUSUS PRINT LAPORAN -->
<style>
@media print {
    @page {
        size: A4 portrait;
        margin: 10mm;
    }

    /* Sembunyikan seluruh elemen navigasi template, sidebar, dan header brand Workspace App */
    aside, nav, header, footer, button, .print\:hidden, 
    div:has(> h1), 
    .workspace-logo,
    nav[role="navigation"],
    /* Menargetkan elemen brand sisa di layout utama */
    body > div:first-child > div:first-child {
        display: none !important;
    }
    
    /* Paksa tampilkan elemen cetak */
    .print\:block {
        display: block !important;
    }
    .print\:flex {
        display: flex !important;
    }

    /* Bersihkan background dan atur lebar dokumen cetak */
    body {
        background: white !important;
        color: black !important;
        margin: 0 !important;
        padding: 0 !important;
        width: 100% !important;
    }
    
    .max-w-5xl {
        width: 100% !important;
        max-width: 100% !important;
        margin: 0 !important;
        padding: 0 !important;
    }

    /* Kunci tabel agar pas memenuhi lebar A4 tanpa terpotong */
    table {
        width: 100% !important;
        table-layout: fixed !important;
        border-collapse: collapse !important;
    }
    /* th, td {
        border: 1.5px solid #000 !important;
        padding: 6px 8px !important;
        font-size: 11px !important;
        word-wrap: break-word !important;
    } */
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('asset::layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\aset-app\Modules\Asset\resources\views/reports/position.blade.php ENDPATH**/ ?>