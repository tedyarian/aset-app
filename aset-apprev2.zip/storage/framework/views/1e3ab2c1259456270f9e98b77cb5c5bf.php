

<?php $__env->startSection('title', 'Manajemen Aset'); ?>
<?php $__env->startSection('header-title', 'Daftar Semua Aset (Asset Inventory)'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white p-6 rounded-xl shadow-sm border border-slate-200 space-y-4">
    <div class="flex justify-between items-center">
        <h3 class="text-md font-bold text-slate-800">Inventaris Barang & Aset</h3>
        <a href="<?php echo e(route('inventory.create')); ?>" class="bg-blue-600 text-white text-xs px-4 py-2 rounded-lg font-medium hover:bg-blue-700 transition">+ Tambah Aset Baru</a>
    </div>

    <div class="overflow-x-auto">
        <table class="w-full text-left text-xs">
    <!-- Perbarui bagian header tabel (th) -->
    <thead>
        <tr class="border-b text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
            <th class="px-3 py-3 w-12 text-center">No.Urut</th>
            <th class="px-3 py-3">Kode / Nama Barang</th>
            <th class="px-3 py-3">Merk / Tipe</th>
            <th class="px-3 py-3">Lokasi / Ruangan</th>
            <th class="px-3 py-3">Jumlah</th>
            <th class="px-3 py-3">Status</th>
            <th class="px-3 py-3 text-center">Aksi</th>
        </tr>
    </thead>
    <!-- Perbarui bagian baris data (tbody tr td) -->
    <tbody class="divide-y divide-gray-200 text-sm">
        <?php $__empty_1 = true; $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr class="hover:bg-gray-50">
            <td class="px-3 py-3 text-center text-gray-500 font-medium"><?php echo e($index + 1); ?></td>
            <td class="px-3 py-3">
                <div class="font-semibold text-gray-900"><?php echo e($item->name); ?></div>
                <div class="text-xs text-gray-400">Kode: <?php echo e($item->code ?? '-'); ?></div>
            </td>
            <td class="px-3 py-3 text-gray-600"><?php echo e($item->brand ?? '-'); ?></td>
            <td class="px-3 py-3 text-gray-600">
                <div><?php echo e($item->location->name ?? '-'); ?></div>
                <div class="text-xs text-gray-400">(<?php echo e($item->room->name ?? '-'); ?>)</div>
            </td>
            <td class="px-3 py-3 text-gray-600"><?php echo e($item->quantity ?? 1); ?> Pcs</td>
            <td class="px-3 py-3">
                <span class="px-2 py-0.5 rounded text-xs font-medium <?php echo e($item->status == 'Baik' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'); ?>">
                    <?php echo e($item->status); ?>

                </span>
            </td>
            <td class="px-3 py-3 text-center whitespace-nowrap">
                <div class="inline-flex items-center space-x-1.5">
                    <a href="<?php echo e(route('inventory.show', $item->id)); ?>" class="text-indigo-600 bg-indigo-50 hover:bg-indigo-100 px-2 py-1 rounded text-xs font-semibold">Detail</a>
                    <a href="<?php echo e(route('inventory.edit', $item->id)); ?>" class="text-amber-600 bg-amber-50 hover:bg-amber-100 px-2 py-1 rounded text-xs font-semibold">Edit</a>
                    <a href="<?php echo e(route('inventory.barcode', $item->id)); ?>" class="text-emerald-600 bg-emerald-50 hover:bg-emerald-100 px-2 py-1 rounded text-xs font-semibold" target="_blank">Barcode</a>
                    <form action="<?php echo e(route('inventory.destroy', $item->id)); ?>" method="POST" class="inline-block" onsubmit="return confirm('Hapus aset ini?')">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="text-red-600 bg-red-50 hover:bg-red-100 px-2 py-1 rounded text-xs font-semibold">Hapus</button>
                    </form>
                </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="7" class="px-3 py-4 text-center text-gray-500">Belum ada data inventaris aset.</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('asset::layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\aset-app\Modules\Asset\resources\views/inventory/index.blade.php ENDPATH**/ ?>