

<?php $__env->startSection('title', 'Manajemen Aset'); ?>
<?php $__env->startSection('header-title', 'Daftar Semua Aset (Asset Inventory)'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white p-6 rounded-xl shadow-sm border border-slate-200 space-y-4">
    <div class="flex justify-between items-center">
        <h3 class="text-md font-bold text-slate-800">Inventaris Barang & Aset</h3>
        <a href="<?php echo e(route('inventory.create')); ?>" class="bg-blue-600 text-white text-xs px-4 py-2 rounded-lg font-medium hover:bg-blue-700 transition">+ Tambah Aset Baru</a>
    </div>

    <div class="overflow-x-auto">
        <table class="w-full text-left text-xs">
    <thead>
        <tr class="border-b text-slate-400">
            <th class="py-2 w-12 text-center">No.Urut</th> <!-- Kolom Nomor Urut -->
            <th class="py-2">Kode / Nama Barang</th>
            <th class="py-2">Merk / Tipe</th>
            <th class="py-2">Lokasi / Ruangan</th>
            <th class="py-2">Jumlah</th>
            <th class="py-2">Status</th>
            <th class="py-2 text-right">Aksi</th>
        </tr>
    </thead>
    <tbody class="divide-y divide-slate-100">
        <?php $__empty_1 = true; $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <!-- Menampilkan nomor urut otomatis berdasarkan perulangan loop -->
                <td class="py-2.5 text-center font-medium text-slate-600">
                    <?php echo e($loop->iteration); ?>

                </td>
                <td class="py-2.5">
                    <span class="font-bold text-slate-700 block"><?php echo e($item->name); ?></span>
                    <span class="text-slate-400 text-[11px] font-mono">Kode: <?php echo e($item->code); ?></span>
                </td>
                <td class="py-2.5 text-slate-600"><?php echo e($item->brand ?? '-'); ?></td>
                <td class="py-2.5 text-slate-600">
                    <?php echo e($item->location->name ?? '-'); ?> 
                    <span class="block text-[11px] text-slate-400">(<?php echo e($item->room->name ?? '-'); ?>)</span>
                </td>
                <td class="py-2.5 font-semibold text-slate-700"><?php echo e($item->quantity); ?> Pcs</td>
                <td class="py-2.5">
                    <span class="px-2 py-0.5 rounded text-[10px] font-medium bg-emerald-100 text-emerald-700">
                        <?php echo e($item->status); ?>

                    </span>
                </td>
                <td class="py-2.5 text-right space-x-2">
                    <a href="<?php echo e(route('inventory.show', $item->id)); ?>" class="text-blue-600 hover:underline">Detail</a>
                    <a href="<?php echo e(route('inventory.barcode', $item->id)); ?>" class="text-emerald-600 hover:underline">Barcode</a>
                    <form action="<?php echo e(route('inventory.destroy', $item->id)); ?>" method="POST" class="inline-block" onsubmit="return confirm('Yakin ingin menghapus aset ini?')">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="text-red-600 hover:underline">Hapus</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="7" class="py-4 text-center text-slate-400">Belum ada data inventaris aset.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('asset::layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/simbaram/aset-app/Modules/Asset/resources/views/inventory/index.blade.php ENDPATH**/ ?>