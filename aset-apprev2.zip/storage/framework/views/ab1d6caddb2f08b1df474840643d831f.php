

<?php $__env->startSection('title', 'Laporan Barang Berdasarkan Ruangan'); ?>
<?php $__env->startSection('header-title', 'Laporan Inventaris Ruangan (DIR)'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-6xl mx-auto space-y-6">

    <!-- FORM FILTER RUANGAN (Hidden saat print) -->
    <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm print:hidden">
        <form action="<?php echo e(route('reports.room')); ?>" method="GET" class="flex flex-col md:flex-row gap-4 items-end">
            <div class="flex-1">
                <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Pilih Ruangan</label>
                <select name="room_id" class="w-full border border-slate-300 rounded-lg px-3 py-2 text-xs bg-white focus:ring-2 focus:ring-indigo-500 outline-none" required>
                    <option value="">-- Pilih Ruangan --</option>
                    <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($room->id); ?>" <?php echo e($selectedRoomId == $room->id ? 'selected' : ''); ?>>
                            <?php echo e($room->name); ?> (<?php echo e($room->location->name ?? '-'); ?>)
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="flex gap-2">
                <button type="submit" class="px-4 py-2 bg-indigo-600 text-white text-xs font-semibold rounded-lg hover:bg-indigo-700 transition">
                    🔍 Tampilkan Laporan
                </button>
                <?php if($selectedRoomId): ?>
                    <button type="button" onclick="window.print()" class="px-4 py-2 bg-slate-100 text-slate-700 text-xs font-semibold rounded-lg border border-slate-300 hover:bg-slate-200 transition">
                        🖨️ Cetak / PDF
                    </button>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <?php if($selectedRoom): ?>
        <!-- KOP SURAT KHUSUS CETAK -->
        <div class="print-header hidden print:block text-center space-y-1 pb-4 border-b-2 border-slate-800 mb-4">
            <h2 class="text-base font-bold uppercase tracking-wider text-slate-900">KEMENTERIAN / LEMBAGA / INSTANSI ANDA</h2>
            <h1 class="text-lg font-extrabold uppercase text-slate-900">DAFTAR INVENTARIS RUANGAN (DIR)</h1>
            <p class="text-xs text-slate-600">Lokasi: <?php echo e($selectedRoom->location->name ?? '-'); ?> | Ruangan: <?php echo e($selectedRoom->name); ?></p>
        </div>

        <!-- REKAP RUANGAN & TABEL ASET -->
        <div class="bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-4">
            <div class="flex justify-between items-center text-xs text-slate-700 border-b pb-3 print:border-b-0">
                <div>
                    <p><span class="font-bold">Ruangan:</span> <?php echo e($selectedRoom->name); ?></p>
                    <p><span class="font-bold">Gedung / Lokasi:</span> <?php echo e($selectedRoom->location->name ?? '-'); ?></p>
                    <p><span class="font-bold">Departemen / Divisi:</span> <?php echo e($selectedRoom->department->name ?? '-'); ?></p>
                </div>
                <div class="text-right">
                    <p><span class="font-bold">Total Item:</span> <?php echo e($assets->count()); ?> Barang</p>
                    <p><span class="font-bold">Tanggal Cetak:</span> <?php echo e(date('d F Y')); ?></p>
                </div>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs border-collapse">
                    <thead>
                        <tr class="border-b-2 border-slate-300 text-slate-700 bg-slate-50 print:bg-transparent">
                            <th class="py-2.5 px-3 border border-slate-300 text-center">No</th>
                            <th class="py-2.5 px-3 border border-slate-300">Kode BMN</th>
                            <th class="py-2.5 px-3 border border-slate-300">Nama Barang</th>
                            <th class="py-2.5 px-3 border border-slate-300">Merk / Tipe</th>
                            <th class="py-2.5 px-3 border border-slate-300 text-center">Jumlah</th>
                            <th class="py-2.5 px-3 border border-slate-300">Kondisi</th>
                            <th class="py-2.5 px-3 border border-slate-300">Penanggung Jawab</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-200">
                        <?php $__empty_1 = true; $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="py-2 px-3 border border-slate-300 text-center"><?php echo e($index + 1); ?></td>
                                <td class="py-2 px-3 border border-slate-300 font-mono font-bold text-slate-800"><?php echo e($item->code); ?></td>
                                <td class="py-2 px-3 border border-slate-300 font-semibold text-slate-700"><?php echo e($item->name); ?></td>
                                <td class="py-2 px-3 border border-slate-300 text-slate-600"><?php echo e($item->brand ?? '-'); ?></td>
                                <td class="py-2 px-3 border border-slate-300 text-center font-bold"><?php echo e($item->quantity); ?> <?php echo e($item->unit); ?></td>
                                <td class="py-2 px-3 border border-slate-300"><?php echo e($item->status); ?></td>
                                <td class="py-2 px-3 border border-slate-300 text-slate-600"><?php echo e($item->pic ?? '-'); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="py-4 text-center text-slate-400 border border-slate-300">Belum ada aset terdaftar di ruangan ini.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- TANDA TANGAN / PENGESAHAN -->
        <div class="print-footer hidden print:flex justify-between pt-10 text-xs text-slate-800">
            <div class="text-center space-y-12">
                <p>Mengetahui,<br>Kepala Unit / Pengelola Barang</p>
                <p class="font-bold underline">( _________________________ )</p>
            </div>
            <div class="text-center space-y-12">
                <p>Bengkulu, <?php echo e(date('d F Y')); ?><br>Penanggung Jawab Ruangan</p>
                <p class="font-bold underline">( <?php echo e($selectedRoom->pic ?? '_________________________'); ?> )</p>
            </div>
        </div>
    <?php else: ?>
        <div class="bg-white p-8 rounded-xl border border-slate-200 text-center text-slate-400 text-xs">
            Silakan pilih ruangan di atas untuk menampilkan Daftar Inventaris Ruangan.
        </div>
    <?php endif; ?>

    <div class="flex justify-end print:hidden">
        <a href="<?php echo e(route('reports.index')); ?>" class="px-4 py-2 bg-slate-100 text-slate-600 rounded-lg text-xs font-medium hover:bg-slate-200 transition">
            Kembali ke Pusat Laporan
        </a>
    </div>
</div>

<!-- CSS KHUSUS PRINT LAPORAN RUANGAN -->
<style>
@media print {
    aside, nav, header, button, .print\:hidden {
        display: none !important;
    }
    .print\:block { display: block !important; }
    .print\:flex { display: flex !important; }
    
    body {
        background: white !important;
        color: black !important;
        margin: 0 !important;
        padding: 10px !important;
    }
    main, .max-w-6xl {
        width: 100% !important;
        max-width: 100% !important;
        margin: 0 !important;
        padding: 0 !important;
    }
    table {
        width: 100% !important;
        border-collapse: collapse !important;
    }
    th, td {
        border: 1px solid #cbd5e1 !important;
        padding: 6px 8px !important;
        font-size: 11px !important;
    }
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('asset::layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/simbaram/aset-app/Modules/Asset/resources/views/reports/room.blade.php ENDPATH**/ ?>