

<?php $__env->startSection('title', 'Pengaturan & Hak Akses'); ?>
<?php $__env->startSection('header-title', 'Pengaturan & Hak Akses (Settings & Users)'); ?>

<?php $__env->startSection('content'); ?>

                <!-- Bagian 1: Pengaturan Umum -->
                <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                    <h3 class="text-lg font-bold text-slate-800 mb-4">1. Pengaturan Umum (General Settings)</h3>
                    <form action="<?php echo e(route('settings.update')); ?>" method="POST" class="space-y-4">
                        <?php echo csrf_field(); ?>
                        <div>
                            <label class="block text-sm font-medium text-slate-600 mb-1">Nama Fakultas</label>
                            <input type="text" name="company_name" value="Hukum" class="w-full border border-slate-300 rounded-lg px-4 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-slate-600 mb-1">Unit</label>
                            <input type="text" name="asset_code_format" value="Rumah Tangga" class="w-full border border-slate-300 rounded-lg px-4 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none">
                            <span class="text-xs text-slate-400 mt-1 block">Contoh: Rumah Tangga</span>
                        </div>
                        <button type="submit" class="bg-blue-600 text-white px-5 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition">Simpan Perubahan</button>
                    </form>
                </div>

                <!-- Bagian 2: Manajemen Pengguna (Users & Roles) -->
                <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                    <h3 class="text-lg font-bold text-slate-800 mb-4">2. Manajemen Pengguna (Users & Roles)</h3>
                    
                   <!-- Form Tambah / Edit Pengguna -->
                    <form action="<?php echo e(isset($user) ? route('settings.users.update', $user->id) : route('settings.users.store')); ?>" method="POST" class="bg-slate-50 p-4 rounded-lg border border-slate-200 mb-6 space-y-4">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($user)): ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="flex justify-between items-center">
                                <h4 class="text-sm font-semibold text-slate-700">Edit Pengguna: <?php echo e($user->name); ?></h4>
                                <a href="<?php echo e(route('settings.index')); ?>" class="text-xs text-red-600 hover:underline">Batal Edit</a>
                            </div>
                        <?php else: ?>
                            <h4 class="text-sm font-semibold text-slate-700">Tambah Pengguna Baru</h4>
                        <?php endif; ?>
                        
                        <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                            <!-- Nama -->
                            <div>
                                <label class="block text-xs font-medium text-slate-600 mb-1">Nama Lengkap</label>
                                <input type="text" name="name" value="<?php echo e(isset($user) ? $user->name : old('name')); ?>" placeholder="Contoh: Budi Staff" class="w-full border border-slate-300 rounded-lg px-3 py-1.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none" required>
                            </div>

                            <!-- Email -->
                            <div>
                                <label class="block text-xs font-medium text-slate-600 mb-1">Email</label>
                                <input type="email" name="email" value="<?php echo e(isset($user) ? $user->email : old('email')); ?>" placeholder="budi@example.com" class="w-full border border-slate-300 rounded-lg px-3 py-1.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none" required>
                            </div>

                            <!-- Role / Tingkatan -->
                            <div>
                                <label class="block text-xs font-medium text-slate-600 mb-1">Role / Tingkatan</label>
                                <select name="role" class="w-full border border-slate-300 rounded-lg px-3 py-1.5 text-sm bg-white focus:ring-2 focus:ring-blue-500 outline-none" required>
                                    <option value="Super Admin" <?php echo e((isset($user) && $user->role == 'Super Admin') ? 'selected' : ''); ?>>Super Admin</option>
                                    <option value="Staff Gudang" <?php echo e((isset($user) && $user->role == 'Staff Gudang') ? 'selected' : ''); ?>>Staff Gudang</option>
                                    <option value="Viewer/Auditor" <?php echo e((isset($user) && $user->role == 'Viewer/Auditor') ? 'selected' : ''); ?>>Viewer / Auditor</option>
                                </select>
                            </div>

                            <!-- Password -->
                            <div>
                                <label class="block text-xs font-medium text-slate-600 mb-1">Password <?php echo e(isset($user) ? '(Opsional)' : ''); ?></label>
                                <input type="password" name="password" placeholder="<?php echo e(isset($user) ? 'Kosongkan jika tidak diubah' : 'Minimal 6 karakter'); ?>" class="w-full border border-slate-300 rounded-lg px-3 py-1.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none" <?php echo e(isset($user) ? '' : 'required'); ?>>
                            </div>
                        </div>

                        <button type="submit" class="bg-blue-600 text-white text-xs px-4 py-2 rounded-lg font-medium hover:bg-blue-700 transition">
                            <?php echo e(isset($user) ? 'Perbarui Pengguna' : '+ Simpan Pengguna'); ?>

                        </button>
                    </form>

                    <!-- Tabel Daftar Pengguna -->
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="border-b text-sm text-slate-500">
                                <th class="py-3">Nama</th>
                                <th class="py-3">Email</th>
                                <th class="py-3">Role / Tingkatan</th>
                                <th class="py-3">Aksi</th>
                            </tr>
                        </thead>
                        <tbody class="text-sm divide-y">
                            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="py-3 font-medium text-slate-700"><?php echo e($user->name); ?></td>
                                <td class="py-3 text-slate-600"><?php echo e($user->email); ?></td>
                                <td class="py-3">
                                    <span class="px-2 py-1 rounded text-xs font-semibold 
                                        <?php echo e($user->role == 'Super Admin' ? 'bg-purple-100 text-purple-700' : ($user->role == 'Staff Gudang' ? 'bg-blue-100 text-blue-700' : 'bg-emerald-100 text-emerald-700')); ?>">
                                        <?php echo e($user->role); ?>

                                    </span>
                                </td>
                                <td class="py-3 text-slate-500 flex items-center space-x-3">
                                    <!-- Tombol Edit -->
                                    <a href="<?php echo e(route('settings.users.edit', $user->id)); ?>" class="text-blue-600 hover:underline font-medium">Edit</a>

                                    <!-- Tombol Hapus Menggunakan Form DELETE -->
                                    <form action="<?php echo e(route('settings.users.destroy', $user->id)); ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus pengguna ini?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="text-red-600 hover:underline font-medium bg-transparent border-0 cursor-pointer p-0">Hapus</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="py-4 text-center text-slate-400">Belum ada data pengguna.</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('asset::layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/simbaram/aset-app/Modules/Asset/resources/views/settings/index.blade.php ENDPATH**/ ?>