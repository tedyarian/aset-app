

<?php $__env->startSection('title', 'Detail Aset'); ?>
<?php $__env->startSection('header-title', 'Detail & Riwayat Aset'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6 max-w-4xl mx-auto">
    <!-- Header Info -->
    <div class="bg-white p-6 rounded-xl shadow-sm border border-slate-200 flex justify-between items-start">
        <div>
            <span class="text-xs font-mono bg-slate-100 text-slate-600 px-2 py-1 rounded"><?php echo e($asset->code); ?></span>
            <h2 class="text-xl font-bold text-slate-800 mt-2"><?php echo e($asset->name); ?></h2>
            <p class="text-xs text-slate-500">Merk/Tipe: <?php echo e($asset->brand ?? '-'); ?></p>
        </div>
        <a href="<?php echo e(route('inventory.index')); ?>" class="text-xs bg-slate-100 text-slate-700 px-3 py-1.5 rounded-lg hover:bg-slate-200">&larr; Kembali</a>
    </div>

    <!-- Grid Informasi (Lokasi, Status, & Foto) -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        <!-- 1. Informasi Lokasi & Kepemilikan -->
        <div class="bg-white p-5 rounded-xl shadow-sm border border-slate-200 space-y-3">
            <h4 class="text-xs font-bold text-slate-400 uppercase tracking-wider">Lokasi & Kepemilikan</h4>
            <div class="text-xs space-y-2">
                <p><strong class="text-slate-600">Departemen:</strong> <?php echo e($asset->department->name ?? '-'); ?></p>
                <p><strong class="text-slate-600">Lokasi Gedung:</strong> <?php echo e($asset->location->name ?? '-'); ?></p>
                <p><strong class="text-slate-600">Ruangan:</strong> <?php echo e($asset->room->name ?? '-'); ?></p>
                <p><strong class="text-slate-600">Penanggung Jawab:</strong> <?php echo e($asset->pic ?? '-'); ?></p>
            </div>
        </div>

        <!-- 2. Status & Jumlah -->
        <div class="bg-white p-5 rounded-xl shadow-sm border border-slate-200 space-y-3">
            <h4 class="text-xs font-bold text-slate-400 uppercase tracking-wider">Status & Jumlah</h4>
            <div class="text-xs space-y-2">
                <p><strong class="text-slate-600">Jumlah:</strong> <?php echo e($asset->quantity); ?> <?php echo e($asset->unit); ?></p>
                <p><strong class="text-slate-600">Kondisi:</strong> 
                    <span class="px-2 py-0.5 rounded text-[10px] bg-emerald-100 text-emerald-700 font-medium"><?php echo e($asset->status); ?></span>
                </p>
                <p><strong class="text-slate-600">Tanggal Input:</strong> <?php echo e($asset->created_at->format('d M Y')); ?></p>
            </div>
        </div>

        <!-- 3. Foto Fisik Aset -->
        <div class="bg-white p-5 rounded-xl shadow-sm border border-slate-200 space-y-3">
            <h4 class="text-xs font-bold text-slate-400 uppercase tracking-wider">Foto Fisik Barang</h4>
            <div>
                <?php if($asset->image): ?>
                    <img src="<?php echo e(asset($asset->image)); ?>" alt="Foto Aset" class="w-full h-32 object-cover rounded-lg border border-slate-200">
                <?php else: ?>
                    <div class="w-full h-32 bg-slate-50 border border-dashed border-slate-300 rounded-lg flex items-center justify-center text-xs text-slate-400 text-center p-2">
                        Tidak ada foto fisik diunggah.
                    </div>
                <?php endif; ?>
            </div>
        </div>

    </div>

    <!-- Riwayat Aset -->
    <div class="bg-white p-6 rounded-xl shadow-sm border border-slate-200 space-y-4">
        <h3 class="text-sm font-bold text-slate-800">Riwayat Mutasi & Peminjaman Aset</h3>
        <div class="border-t pt-3 text-xs text-slate-500">
            <p>Belum ada catatan riwayat mutasi atau servis untuk aset ini.</p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('asset::layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/simbaram/aset-app/Modules/Asset/resources/views/inventory/show.blade.php ENDPATH**/ ?>