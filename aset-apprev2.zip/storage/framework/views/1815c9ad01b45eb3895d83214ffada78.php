

<?php $__env->startSection('title', 'Cetak Barcode'); ?>
<?php $__env->startSection('header-title', 'Cetak Barcode / QR Code Aset'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white p-8 rounded-xl shadow-sm border border-slate-200 max-w-md mx-auto text-center space-y-6">
    <div>
        <h3 class="text-lg font-bold text-slate-800"><?php echo e($asset->name); ?></h3>
        <p class="text-xs text-slate-500 font-mono mt-1"><?php echo e($asset->code); ?></p>
    </div>

    <!-- Simulasi Label Barcode -->
    <div class="border-2 border-dashed border-slate-300 p-6 rounded-xl bg-slate-50 inline-block w-full space-y-3">
        <div class="font-mono text-2xl font-bold tracking-widest text-slate-800">*<?php echo e($asset->code); ?>*</div>
        <div class="text-[11px] text-slate-600">Lokasi: <?php echo e($asset->location->name ?? '-'); ?> (<?php echo e($asset->room->name ?? '-'); ?>)</div>
    </div>

    <div class="flex justify-center space-x-3">
        <button onclick="window.print()" class="bg-blue-600 text-white text-xs px-4 py-2 rounded-lg font-medium hover:bg-blue-700">Cetak Label</button>
        <a href="<?php echo e(route('inventory.index')); ?>" class="bg-slate-200 text-slate-700 text-xs px-4 py-2 rounded-lg font-medium">Kembali</a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('asset::layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/simbaram/aset-app/Modules/Asset/resources/views/inventory/barcode.blade.php ENDPATH**/ ?>