<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Workspace App'); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-100 font-sans">
    
    <div class="flex h-screen overflow-hidden">
        
        <!-- Sidebar Menu -->
        <div class="w-64 bg-slate-900 text-white flex flex-col">
            <div class="p-5 text-xl font-bold tracking-wider border-b border-slate-800">Workspace App</div>
            <nav class="flex-1 p-4 space-y-2 text-sm">
                <a href="<?php echo e(route('dashboard')); ?>" class="block px-4 py-2.5 rounded <?php echo e(request()->routeIs('dashboard') ? 'bg-blue-600 text-white font-medium' : 'hover:bg-slate-800 text-slate-300'); ?>">Dashboard</a>
                <a href="<?php echo e(route('inventory.index')); ?>" class="block px-4 py-2.5 rounded <?php echo e(request()->routeIs('inventory.*') ? 'bg-blue-600 text-white font-medium' : 'hover:bg-slate-800 text-slate-300'); ?>">Manajemen Aset</a>
                <a href="<?php echo e(route('master.index')); ?>" class="block px-4 py-2.5 rounded <?php echo e(request()->routeIs('master.*') ? 'bg-blue-600 text-white font-medium' : 'hover:bg-slate-800 text-slate-300'); ?>">Master Data</a>
                <a href="<?php echo e(route('transactions.index')); ?>" class="block px-4 py-2.5 rounded <?php echo e(request()->routeIs('transactions.*') ? 'bg-blue-600 text-white font-medium' : 'hover:bg-slate-800 text-slate-300'); ?>">Transaksi & Mutasi</a>
                <a href="<?php echo e(route('audits.index')); ?>" class="block px-4 py-2.5 rounded <?php echo e(request()->routeIs('audits.*') ? 'bg-blue-600 text-white font-medium' : 'hover:bg-slate-800 text-slate-300'); ?>">Audit & Opname</a>
                <a href="<?php echo e(route('reports.index')); ?>" class="block px-4 py-2.5 rounded <?php echo e(request()->routeIs('reports.*') ? 'bg-blue-600 text-white font-medium' : 'hover:bg-slate-800 text-slate-300'); ?>">Laporan (Reports)</a>
                <a href="<?php echo e(route('settings.index')); ?>" class="block px-4 py-2.5 rounded <?php echo e(request()->routeIs('settings.*') ? 'bg-blue-600 text-white font-medium' : 'hover:bg-slate-800 text-slate-300'); ?>">Pengaturan</a>
            </nav>
                <div class="p-4 border-t border-slate-800">
                <form action="<?php echo e(route('logout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="w-full text-left px-4 py-2 rounded text-red-400 hover:bg-slate-800 text-sm">Logout</button>
                </form>
            </div>
        </div>

        <!-- MAIN CONTENT AREA -->
        <div class="flex-1 flex flex-col overflow-y-auto">
            <header class="bg-white shadow-sm h-16 flex items-center justify-between px-8">
                <h1 class="text-lg font-semibold text-slate-700"><?php echo $__env->yieldContent('header-title', 'Aplikasi Manajemen Aset'); ?></h1>
                <span class="font-medium text-slate-800"><?php echo e(Auth::user()->name ?? 'Admin'); ?></span>
            </header>

            <main class="p-8">
                <!-- Flash Message Global -->
                <?php if(session('success')): ?>
                    <div class="mb-6 bg-emerald-100 border border-emerald-400 text-emerald-700 px-4 py-3 rounded-lg text-sm">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <!-- Bagian ini akan diisi dinamis oleh halaman lain -->
                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </div>

    </div>
    
</body>
</html><?php /**PATH C:\xampp\htdocs\aset-app\Modules\Asset\resources\views/layouts/app.blade.php ENDPATH**/ ?>