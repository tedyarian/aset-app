

<?php $__env->startSection('title', 'Laporan Posisi Aset'); ?>
<?php $__env->startSection('header-title', 'Laporan Posisi & Rekapitulasi Aset'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-6xl mx-auto space-y-6">
    
    <!-- KOP SURAT KHUSUS CETAK (Hanya Muncul Saat Diprint) -->
    <div class="print-header hidden print:block text-center space-y-1 pb-4 border-b-2 border-slate-800 mb-6">
        <h2 class="text-base font-bold uppercase tracking-wider text-slate-900">KEMENTERIAN / LEMBAGA / INSTANSI ANDA</h2>
        <h1 class="text-lg font-extrabold uppercase text-slate-900">LAPORAN REKAPITULASI POSISI ASET BMN</h1>
        <p class="text-xs text-slate-600">Periode Tahun Anggaran 2026</p>
    </div>

    <div class="bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-4">
        <div class="flex justify-between items-center print:hidden">
            <h3 class="text-xs font-bold text-slate-700 uppercase">DAFTAR REKAPITULASI POSISI ASET</h3>
            <button onclick="window.print()" class="px-3 py-1.5 bg-slate-100 text-slate-600 rounded-lg text-xs font-medium hover:bg-slate-200 transition">🖨️ Cetak / PDF</button>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left text-xs border-collapse">
                <thead>
                    <tr class="border-b-2 border-slate-300 text-slate-700 bg-slate-50 print:bg-transparent">
                        <th class="py-2 px-2 border border-slate-300">No</th>
                        <th class="py-2 px-2 border border-slate-300">Kode BMN</th>
                        <th class="py-2 px-2 border border-slate-300">Nama Aset</th>
                        <th class="py-2 px-2 border border-slate-300">Lokasi / Ruangan</th>
                        <th class="py-2 px-2 border border-slate-300">Penanggung Jawab (PIC)</th>
                        <th class="py-2 px-2 border border-slate-300">Kondisi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-200">
                    <?php $__empty_1 = true; $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="py-2 px-2 border border-slate-300 text-center"><?php echo e($index + 1); ?></td>
                            <td class="py-2 px-2 border border-slate-300 font-bold text-slate-700"><?php echo e($asset->code); ?></td>
                            <td class="py-2 px-2 border border-slate-300 text-slate-600"><?php echo e($asset->name); ?></td>
                            <td class="py-2 px-2 border border-slate-300 text-slate-600"><?php echo e($asset->room->name ?? '-'); ?></td>
                            <td class="py-2 px-2 border border-slate-300 text-slate-600"><?php echo e($asset->pic ?? '-'); ?></td>
                            <td class="py-2 px-2 border border-slate-300 text-slate-600 font-semibold"><?php echo e($asset->status); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="py-4 text-center text-slate-400 border border-slate-300">Tidak ada data aset ditemukan.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- TANDA TANGAN / PENGETAHUAN (Hanya Muncul Saat Diprint) -->
    <div class="print-footer hidden print:flex justify-between pt-12 text-xs text-slate-800">
        <div class="text-center space-y-12">
            <p>Mengetahui,<br>Kepala Unit / Pengelola Barang</p>
            <p class="font-bold underline">( _________________________ )</p>
        </div>
        <div class="text-center space-y-12">
            <p>Bengkulu, <?php echo e(date('d F Y')); ?><br>Petugas / Pengurus Aset</p>
            <p class="font-bold underline">( Tedy Arian )</p>
        </div>
    </div>

    <div class="flex justify-end print:hidden">
        <a href="<?php echo e(route('reports.index')); ?>" class="px-4 py-2 bg-slate-100 text-slate-600 rounded-lg text-xs font-medium hover:bg-slate-200 transition">Kembali ke Menu Laporan</a>
    </div>
</div>

<!-- Contoh pada file layouts/app.blade.php -->
    <div class="p-4 print:hidden">
        <h1 class="text-base font-bold text-slate-700">Workspace App</h1>
    </div>

<!-- CSS KHUSUS PRINT LAPORAN -->
<style>
@media print {
    /* Sembunyikan sidebar, header navigasi, tombol web, dan teks/logo Workspace App */
    aside, nav, header, button, .print\:hidden, 
    div:has(> h1), /* Menyembunyikan kontainer judul brand Workspace App jika ada */
    .workspace-logo {
        display: none !important;
    }
    
    /* Pastikan kop surat dan tanda tangan khusus print tampil dengan benar */
    .print\:block {
        display: block !important;
    }
    .print\:flex {
        display: flex !important;
    }
    
    /* Atur layout halaman cetak penuh agar bersih tanpa sisa margin kiri */
    body {
        background: white !important;
        color: black !important;
        margin: 0 !important;
        padding: 10px !important;
    }
    main, .max-w-6xl {
        width: 100% !important;
        max-width: 100% !important;
        margin: 0 !important;
        padding: 0 !important;
    }

    /* Format tabel cetak agar memiliki garis tegas */
    table {
        width: 100% !important;
        border-collapse: collapse !important;
    }
    th, td {
        border: 1px solid #cbd5e1 !important;
        padding: 6px 8px !important;
        font-size: 11px !important;
    }
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('asset::layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/simbaram/aset-app/Modules/Asset/resources/views/reports/position.blade.php ENDPATH**/ ?>