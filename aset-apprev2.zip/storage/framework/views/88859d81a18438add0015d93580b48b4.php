<?php
    $kop = \Modules\Asset\Models\InstitutionKop::first();
    $logoPath = $kop && $kop->logo ? public_path('storage/' . $kop->logo) : null;
    $logoUrl = $kop && $kop->logo ? asset('storage/' . $kop->logo) : asset('images/unib-logo.png');
?>

<table style="width: 100%; border-collapse: collapse; border-bottom: 3px double #000; padding-bottom: 6px; margin-bottom: 15px; font-family: <?php echo e($kop->font_family ?? 'Arial, sans-serif'); ?>;">
    <tr>
        <!-- Kolom Logo di Kiri (Proporsional) -->
        <td style="width: 15%; text-align: center; vertical-align: middle; padding-left: 10px;">
            <img src="<?php echo e($logoPath && file_exists($logoPath) ? $logoUrl : asset('images/unib-logo.png')); ?>" alt="Logo" style="width: 70px; height: auto;">
        </td>

        <!-- Kolom Teks 5 Baris di Tengah -->
        <td style="width: 85%; text-align: center; vertical-align: middle; padding-right: 15%;>
            <div style="font-size: <?php echo e($kop->size_1 ?? '13px'); ?>; font-weight: bold; text-transform: uppercase; line-height: 1.2;">
                <?php echo e($kop->line_1 ?? ''); ?>

            </div>
            <div style="font-size: <?php echo e($kop->size_2 ?? '15px'); ?>; font-weight: bold; text-transform: uppercase; line-height: 1.2;">
                <?php echo e($kop->line_2 ?? ''); ?>

            </div>
            <div style="font-size: <?php echo e($kop->size_3 ?? '12px'); ?>; font-weight: bold; text-transform: uppercase; line-height: 1.2;">
                <?php echo e($kop->line_3 ?? ''); ?>

            </div>
            <div style="font-size: <?php echo e($kop->size_4 ?? '10px'); ?>; line-height: 1.1; margin-top: 2px;">
                <?php echo e($kop->line_4 ?? ''); ?>

            </div>
            <div style="font-size: <?php echo e($kop->size_5 ?? '10px'); ?>; line-height: 1.1;">
                <?php echo e($kop->line_5 ?? ''); ?>

            </div>
        </td>
    </tr>
</table><?php /**PATH C:\xampp\htdocs\aset-app\Modules\Asset\resources\views/reports/partials/kop.blade.php ENDPATH**/ ?>