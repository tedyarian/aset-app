

<?php $__env->startSection('title', 'Input Mutasi Aset'); ?>
<?php $__env->startSection('header-title', 'Form Mutasi / Perpindahan Aset'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-2xl mx-auto bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
    <form action="<?php echo e(route('transactions.mutation.store')); ?>" method="POST" class="space-y-4">
        <?php echo csrf_field(); ?>

        <!-- Pilih Aset -->
        <div>
            <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Pilih Aset</label>
            <select name="asset_item_id" class="w-full border border-slate-300 rounded-lg px-3 py-2 text-xs bg-white outline-none focus:ring-2 focus:ring-blue-500" required>
                <option value="">-- Pilih Aset yang Akan Dimutasi --</option>
                <?php $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($asset->id); ?>"><?php echo e($asset->code); ?> - <?php echo e($asset->name); ?> (Lokasi Saat Ini: <?php echo e($asset->room->name ?? '-'); ?>)</option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <!-- Ruangan Tujuan -->
        <div>
            <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Pindah ke Ruangan Tujuan</label>
            <select name="to_room_id" class="w-full border border-slate-300 rounded-lg px-3 py-2 text-xs bg-white outline-none focus:ring-2 focus:ring-blue-500" required>
                <option value="">-- Pilih Ruangan Tujuan --</option>
                <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($room->id); ?>"><?php echo e($room->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <!-- Penanggung Jawab Baru (PIC) -->
        <div>
            <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Penanggung Jawab Baru (PIC)</label>
            <input type="text" name="to_pic" class="w-full border border-slate-300 rounded-lg px-3 py-2 text-xs outline-none focus:ring-2 focus:ring-blue-500" placeholder="Nama Pegawai / Staff Penerima">
        </div>

        <!-- Tanggal Mutasi -->
        <div>
            <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Tanggal Mutasi</label>
            <input type="date" name="mutation_date" value="<?php echo e(date('Y-m-d')); ?>" class="w-full border border-slate-300 rounded-lg px-3 py-2 text-xs outline-none focus:ring-2 focus:ring-blue-500" required>
        </div>

        <!-- Alasan / Keterangan -->
        <div>
            <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Alasan Mutasi / Keterangan</label>
            <textarea name="reason" rows="3" class="w-full border border-slate-300 rounded-lg px-3 py-2 text-xs outline-none focus:ring-2 focus:ring-blue-500" placeholder="Contoh: Perpindahan divisi, perbaikan tata letak ruangan, dll."></textarea>
        </div>

        <!-- Tombol Aksi -->
        <div class="flex justify-end space-x-2 pt-2">
            <a href="<?php echo e(route('transactions.index')); ?>" class="px-4 py-2 bg-slate-100 text-slate-600 rounded-lg text-xs font-medium hover:bg-slate-200 transition">Batal</a>
            <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-lg text-xs font-medium hover:bg-blue-700 transition">Simpan Mutasi</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('asset::layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\aset-app\Modules\Asset\resources\views/transactions/mutation_create.blade.php ENDPATH**/ ?>