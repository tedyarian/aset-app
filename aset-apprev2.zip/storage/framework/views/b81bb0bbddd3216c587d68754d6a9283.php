<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistem Informasi Barang</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        /* 1. LETAK KODE CSS ANIMASI DI DALAM <head> */
        body {
            background: linear-gradient(-45deg, #0f172a, #1e1b4b, #312e81, #0f172a);
            background-size: 400% 400%;
            animation: gradientBG 15s ease infinite;
        }

        @keyframes gradientBG {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        /* Efek Bola Cahaya Mengambang */
        .bg-glow-orb {
            position: absolute;
            width: 350px;
            height: 350px;
            background: rgba(59, 130, 246, 0.15);
            filter: blur(90px);
            border-radius: 50%;
            animation: floatOrb 10s ease-in-out infinite alternate;
            z-index: 0;
        }

        @keyframes floatOrb {
            0% { transform: translateY(-50px) translateX(-50px); }
            100% { transform: translateY(50px) translateX(50px); }
        }
    </style>
</head>
<body class="font-sans flex items-center justify-center h-screen relative overflow-hidden">
    
    <!-- 2. LETAK ELEMEN BOLA CAHAYA DI DALAM <body> (SEBELUM CARD FORM) -->
    <div class="bg-glow-orb"></div>

    <div class="w-full max-w-md bg-white rounded-xl shadow-2xl p-8 border border-slate-200 relative z-10">
        <div class="text-center mb-8">
            <h2 class="text-2xl font-bold text-slate-800">Sistem Informasi Barang</h2>
            <p class="text-sm text-slate-500 mt-1">Silakan masuk menggunakan akun Anda</p>
        </div>

        <?php if($errors->any()): ?>
            <div class="mb-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg text-sm">
                <?php echo e($errors->first()); ?>

            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('login')); ?>" method="POST" class="space-y-4">
            <?php echo csrf_field(); ?>
            <div>
                <label class="block text-xs font-medium text-slate-600 mb-1">Email</label>
                <input type="email" name="email" value="<?php echo e(old('email')); ?>" required placeholder="admin@example.com" class="w-full border border-slate-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none">
            </div>

            <div>
                <label class="block text-xs font-medium text-slate-600 mb-1">Password</label>
                <input type="password" name="password" required placeholder="••••••••" class="w-full border border-slate-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none">
            </div>

            <button type="submit" class="w-full bg-blue-600 text-white py-2.5 rounded-lg text-sm font-medium hover:bg-blue-700 transition shadow-lg shadow-blue-500/30">Masuk</button>
        </form>
    </div>
</body>
</html><?php /**PATH /home/simbaram/aset-app/Modules/Asset/resources/views/auth/login.blade.php ENDPATH**/ ?>