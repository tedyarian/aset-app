

<?php $__env->startSection('title', 'Master Data'); ?>
<?php $__env->startSection('header-title', 'Master Data (Referensi)'); ?>

<?php $__env->startSection('content'); ?>
<div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                   
 <!-- 1. KELOLA DEPARTEMEN -->
    <div class="bg-white p-5 rounded-xl shadow-sm border border-slate-200 flex flex-col justify-between">
        <div>
            <h3 class="text-sm font-bold text-slate-800 mb-3">Daftar Departemen / Divisi</h3>
            
            <form action="<?php echo e(route('master.department.store')); ?>" method="POST" class="flex gap-2 mb-4">
                <?php echo csrf_field(); ?>
                <input type="text" name="name" placeholder="Nama Departemen (Contoh: IT)" class="flex-1 border border-slate-300 rounded-lg px-3 py-1.5 text-xs outline-none focus:ring-2 focus:ring-blue-500" required>
                <button type="submit" class="bg-slate-800 text-white text-xs px-3 py-1.5 rounded-lg font-medium hover:bg-slate-700 whitespace-nowrap">+ Tambah</button>
            </form>

            <div class="border-t border-slate-100 pt-2 overflow-x-auto max-h-60 overflow-y-auto">
                <table class="w-full text-left text-xs">
                    <thead>
                        <tr class="border-b text-slate-400">
                            <th class="py-2 font-medium">Nama</th>
                            <th class="py-2 text-right font-medium">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100">
                        <?php $__empty_1 = true; $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="py-2 text-slate-700 font-medium"><?php echo e($dept->name); ?></td>
                                <td class="py-2 text-right">
                                    <form action="<?php echo e(route('master.department.delete', $dept->id)); ?>" method="POST" onsubmit="return confirm('Hapus departemen ini?');" class="inline">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="text-red-500 hover:underline">Hapus</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="2" class="py-4 text-center text-slate-400">Belum ada data departemen.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- 2. KELOLA LOKASI -->
    <div class="bg-white p-5 rounded-xl shadow-sm border border-slate-200 flex flex-col justify-between">
        <div>
            <h3 class="text-sm font-bold text-slate-800 mb-3">Daftar Lokasi Penyimpanan Aset</h3>
            
            <form action="<?php echo e(route('master.location.store')); ?>" method="POST" class="flex gap-2 mb-4">
                <?php echo csrf_field(); ?>
                <input type="text" name="name" placeholder="Nama Lokasi (Contoh: Gedung A)" class="flex-1 border border-slate-300 rounded-lg px-3 py-1.5 text-xs outline-none focus:ring-2 focus:ring-blue-500" required>
                <button type="submit" class="bg-slate-800 text-white text-xs px-3 py-1.5 rounded-lg font-medium hover:bg-slate-700 whitespace-nowrap">+ Tambah</button>
            </form>

            <div class="border-t border-slate-100 pt-2 overflow-x-auto max-h-60 overflow-y-auto">
                <table class="w-full text-left text-xs">
                    <thead>
                        <tr class="border-b text-slate-400">
                            <th class="py-2 font-medium">Lokasi</th>
                            <th class="py-2 text-right font-medium">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100">
                        <?php $__empty_1 = true; $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="py-2 text-slate-700 font-medium"><?php echo e($loc->name); ?></td>
                                <td class="py-2 text-right">
                                    <form action="<?php echo e(route('master.location.delete', $loc->id)); ?>" method="POST" onsubmit="return confirm('Hapus lokasi ini?');" class="inline">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="text-red-500 hover:underline">Hapus</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="2" class="py-4 text-center text-slate-400">Belum ada data lokasi.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- 3. KELOLA RUANGAN -->
    <div class="bg-white p-5 rounded-xl shadow-sm border border-slate-200 flex flex-col justify-between">
        <div>
            <h3 class="text-sm font-bold text-slate-800 mb-3">Daftar Ruangan</h3>
            
            <form action="<?php echo e(route('master.room.store')); ?>" method="POST" class="flex gap-2 mb-4">
                <?php echo csrf_field(); ?>
                <input type="text" name="name" placeholder="Nama Ruangan (Contoh: Ruang Server)" class="flex-1 border border-slate-300 rounded-lg px-3 py-1.5 text-xs outline-none focus:ring-2 focus:ring-blue-500" required>
                <button type="submit" class="bg-slate-800 text-white text-xs px-3 py-1.5 rounded-lg font-medium hover:bg-slate-700 whitespace-nowrap">+ Tambah</button>
            </form>

            <div class="border-t border-slate-100 pt-2 overflow-x-auto max-h-60 overflow-y-auto">
                <table class="w-full text-left text-xs">
                    <thead>
                        <tr class="border-b text-slate-400">
                            <th class="py-2 font-medium">Nama Ruangan</th>
                            <th class="py-2 text-right font-medium">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100">
                        <?php $__empty_1 = true; $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="py-2 text-slate-700 font-medium"><?php echo e($room->name); ?></td>
                                <td class="py-2 text-right">
                                    <form action="<?php echo e(route('master.room.delete', $room->id)); ?>" method="POST" onsubmit="return confirm('Hapus ruangan ini?');" class="inline">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="text-red-500 hover:underline">Hapus</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="2" class="py-4 text-center text-slate-400">Belum ada data ruangan.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>     
<?php $__env->stopSection(); ?>
<?php echo $__env->make('asset::layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/simbaram/aset-app/Modules/Asset/resources/views/master/index.blade.php ENDPATH**/ ?>