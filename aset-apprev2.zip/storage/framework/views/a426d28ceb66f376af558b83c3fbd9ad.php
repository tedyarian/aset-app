

<?php $__env->startSection('title', 'Laporan Penyusutan Aset'); ?>
<?php $__env->startSection('header-title', 'Laporan Keuangan & Penyusutan (Depreciation)'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-6xl mx-auto space-y-6">
    <div class="bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-4">
        <div class="flex justify-between items-center">
            <h3 class="text-xs font-bold text-slate-700 uppercase">Tabel Kalkulasi Nilai Susut Aset</h3>
            <button onclick="window.print()" class="px-3 py-1.5 bg-slate-100 text-slate-600 rounded-lg text-xs font-medium hover:bg-slate-200">🖨️ Cetak / PDF</button>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left text-xs">
                <thead>
                    <tr class="border-b text-slate-400">
                        <th class="py-2">Kode BMN</th>
                        <th class="py-2">Nama Aset</th>
                        <th class="py-2">Harga Perolehan</th>
                        <th class="py-2">Penyusutan / Tahun</th>
                        <th class="py-2">Nilai Buku Saat Ini</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php $__empty_1 = true; $__currentLoopData = $reportData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="py-3 font-bold text-slate-700"><?php echo e($item->code); ?></td>
                            <td class="py-3 text-slate-600"><?php echo e($item->name); ?></td>
                            <td class="py-3 text-slate-600">Rp <?php echo e(number_format($item->purchase_price ?? 0, 0, ',', '.')); ?></td>
                            <td class="py-3 text-rose-600 font-medium">Rp <?php echo e(number_format($item->depreciation_per_year, 0, ',', '.')); ?></td>
                            <td class="py-3 text-emerald-600 font-bold">Rp <?php echo e(number_format($item->book_value, 0, ',', '.')); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="py-4 text-center text-slate-400">Belum ada data nilai perolehan aset.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="flex justify-end">
        <a href="<?php echo e(route('reports.index')); ?>" class="px-4 py-2 bg-slate-100 text-slate-600 rounded-lg text-xs font-medium hover:bg-slate-200">Kembali ke Menu Laporan</a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('asset::layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\aset-app\Modules\Asset\resources\views/reports/depreciation.blade.php ENDPATH**/ ?>