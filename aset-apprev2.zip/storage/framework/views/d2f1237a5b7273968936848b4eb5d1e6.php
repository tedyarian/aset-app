

<?php $__env->startSection('title', 'Master Data'); ?>
<?php $__env->startSection('header-title', 'Master Data (Referensi)'); ?>

<?php $__env->startSection('content'); ?>
<div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                   
 <!-- 1. KELOLA DEPARTEMEN -->
    <div class="bg-white p-5 rounded-xl shadow-sm border border-slate-200 flex flex-col justify-between">
        <div>
            <h3 class="text-sm font-bold text-slate-800 mb-3">Daftar Departemen / Divisi</h3>
            
            <form action="<?php echo e(route('master.department.store')); ?>" method="POST" class="flex gap-2 mb-4">
                <?php echo csrf_field(); ?>
                <input type="text" name="name" placeholder="Nama Departemen (Contoh: IT)" class="flex-1 border border-slate-300 rounded-lg px-3 py-1.5 text-xs outline-none focus:ring-2 focus:ring-blue-500" required>
                <button type="submit" class="bg-slate-800 text-white text-xs px-3 py-1.5 rounded-lg font-medium hover:bg-slate-700 whitespace-nowrap">+ Tambah</button>
            </form>

            <div class="border-t border-slate-100 pt-2 overflow-x-auto max-h-60 overflow-y-auto">
                <table class="w-full text-left text-xs">
                    <thead>
                        <tr class="border-b text-slate-400">
                            <th class="py-2 font-medium">Nama</th>
                            <th class="py-2 text-right font-medium">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100">
                        <?php $__empty_1 = true; $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="py-2 text-slate-700 font-medium"><?php echo e($dept->name); ?></td>
                                <td class="py-2 text-right">
                                    <form action="<?php echo e(route('master.department.delete', $dept->id)); ?>" method="POST" onsubmit="return confirm('Hapus departemen ini?');" class="inline">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="text-red-500 hover:underline">Hapus</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="2" class="py-4 text-center text-slate-400">Belum ada data departemen.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- 2. KELOLA LOKASI -->
    <div class="bg-white p-5 rounded-xl shadow-sm border border-slate-200 flex flex-col justify-between">
        <div>
            <h3 class="text-sm font-bold text-slate-800 mb-3">Daftar Lokasi Penyimpanan Aset</h3>
            
            <form action="<?php echo e(route('master.location.store')); ?>" method="POST" class="flex gap-2 mb-4">
                <?php echo csrf_field(); ?>
                <input type="text" name="name" placeholder="Nama Lokasi (Contoh: Gedung A)" class="flex-1 border border-slate-300 rounded-lg px-3 py-1.5 text-xs outline-none focus:ring-2 focus:ring-blue-500" required>
                <button type="submit" class="bg-slate-800 text-white text-xs px-3 py-1.5 rounded-lg font-medium hover:bg-slate-700 whitespace-nowrap">+ Tambah</button>
            </form>

            <div class="border-t border-slate-100 pt-2 overflow-x-auto max-h-60 overflow-y-auto">
                <table class="w-full text-left text-xs">
                    <thead>
                        <tr class="border-b text-slate-400">
                            <th class="py-2 font-medium">Lokasi</th>
                            <th class="py-2 text-right font-medium">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100">
                        <?php $__empty_1 = true; $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="py-2 text-slate-700 font-medium"><?php echo e($loc->name); ?></td>
                                <td class="py-2 text-right">
                                    <form action="<?php echo e(route('master.location.delete', $loc->id)); ?>" method="POST" onsubmit="return confirm('Hapus lokasi ini?');" class="inline">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="text-red-500 hover:underline">Hapus</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="2" class="py-4 text-center text-slate-400">Belum ada data lokasi.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- 3. KELOLA RUANGAN -->
    <div class="bg-white p-5 rounded-xl shadow-sm border border-slate-200 flex flex-col justify-between">
        <div>
            <h3 class="text-sm font-bold text-slate-800 mb-3">Daftar Ruangan</h3>
            
            <form action="<?php echo e(route('master.room.store')); ?>" method="POST" class="flex gap-2 mb-4">
                <?php echo csrf_field(); ?>
                <input type="text" name="name" placeholder="Nama Ruangan (Contoh: Ruang Server)" class="flex-1 border border-slate-300 rounded-lg px-3 py-1.5 text-xs outline-none focus:ring-2 focus:ring-blue-500" required>
                <button type="submit" class="bg-slate-800 text-white text-xs px-3 py-1.5 rounded-lg font-medium hover:bg-slate-700 whitespace-nowrap">+ Tambah</button>
            </form>

            <div class="border-t border-slate-100 pt-2 overflow-x-auto max-h-60 overflow-y-auto">
                <table class="w-full text-left text-xs">
                    <thead>
                        <tr class="border-b text-slate-400">
                            <th class="py-2 font-medium">Nama Ruangan</th>
                            <th class="py-2 text-right font-medium">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100">
                        <?php $__empty_1 = true; $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="py-2 text-slate-700 font-medium"><?php echo e($room->name); ?></td>
                                <td class="py-2 text-right">
                                    <form action="<?php echo e(route('master.room.delete', $room->id)); ?>" method="POST" onsubmit="return confirm('Hapus ruangan ini?');" class="inline">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="text-red-500 hover:underline">Hapus</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="2" class="py-4 text-center text-slate-400">Belum ada data ruangan.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Form Master Template KOP Surat -->
    <div class="bg-white p-6 rounded-xl shadow-sm border border-slate-200 mt-6">
        <h3 class="text-lg font-bold text-slate-800 mb-4">Master Template KOP Surat Laporan</h3>
        
        <?php
            $kop = \Modules\Asset\Models\InstitutionKop::first();
        ?>

        <form action="<?php echo e(route('master.kop.update')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
                <!-- Upload Logo -->
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1">Logo Instansi</label>
                    <?php if($kop && $kop->logo): ?>
                        <div class="mb-2">
                            <img src="<?php echo e(asset('storage/' . $kop->logo)); ?>" alt="Logo" class="h-16 w-auto object-contain border p-1 rounded">
                        </div>
                    <?php endif; ?>
                    <input type="file" name="logo" class="w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100">
                </div>

                <!-- Pilih Jenis Font Global -->
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1">Jenis Font (Font Family)</label>
                    <select name="font_family" class="w-full border-slate-300 rounded-md shadow-sm text-sm">
                        <option value="Times New Roman, serif" <?php echo e(($kop->font_family ?? '') == 'Times New Roman, serif' ? 'selected' : ''); ?>>Times New Roman</option>
                        <option value="Arial, sans-serif" <?php echo e(($kop->font_family ?? '') == 'Arial, sans-serif' ? 'selected' : ''); ?>>Arial</option>
                        <option value="Courier New, monospace" <?php echo e(($kop->font_family ?? '') == 'Courier New, monospace' ? 'selected' : ''); ?>>Courier New</option>
                    </select>
                </div>
            </div>

            <hr class="my-4 border-slate-200">

            <!-- Pengaturan 5 Baris Teks dan Ukurannya -->
            <div class="space-y-4">
                <!-- Baris 1 -->
                <div class="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
                    <div class="md:col-span-3">
                        <label class="block text-xs font-semibold text-slate-500 uppercase">Baris 1 (Kementerian / Lembaga)</label>
                        <input type="text" name="line_1" value="<?php echo e($kop->line_1 ?? ''); ?>" placeholder="Contoh: KEMENTERIAN PENDIDIKAN TINGGI, SAIN, DAN TEKNOLOGI" class="w-full border-slate-300 rounded-md text-sm">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-500 uppercase">Ukuran Font</label>
                        <input type="text" name="size_1" value="<?php echo e($kop->size_1 ?? '14px'); ?>" class="w-full border-slate-300 rounded-md text-sm">
                    </div>
                </div>

                <!-- Baris 2 -->
                <div class="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
                    <div class="md:col-span-3">
                        <label class="block text-xs font-semibold text-slate-500 uppercase">Baris 2 (Nama Universitas / Instansi Utama)</label>
                        <input type="text" name="line_2" value="<?php echo e($kop->line_2 ?? ''); ?>" placeholder="Contoh: UNIVERSITAS BENGKULU" class="w-full border-slate-300 rounded-md text-sm">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-500 uppercase">Ukuran Font</label>
                        <input type="text" name="size_2" value="<?php echo e($kop->size_2 ?? '16px'); ?>" class="w-full border-slate-300 rounded-md text-sm">
                    </div>
                </div>

                <!-- Baris 3 -->
                <div class="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
                    <div class="md:col-span-3">
                        <label class="block text-xs font-semibold text-slate-500 uppercase">Baris 3 (Fakultas / Unit Kerja)</label>
                        <input type="text" name="line_3" value="<?php echo e($kop->line_3 ?? ''); ?>" placeholder="Contoh: UPA TEKNOLOGI INFORMASI DAN KOMUNIKASI" class="w-full border-slate-300 rounded-md text-sm">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-500 uppercase">Ukuran Font</label>
                        <input type="text" name="size_3" value="<?php echo e($kop->size_3 ?? '13px'); ?>" class="w-full border-slate-300 rounded-md text-sm">
                    </div>
                </div>

                <!-- Baris 4 -->
                <div class="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
                    <div class="md:col-span-3">
                        <label class="block text-xs font-semibold text-slate-500 uppercase">Baris 4 (Alamat)</label>
                        <input type="text" name="line_4" value="<?php echo e($kop->line_4 ?? ''); ?>" placeholder="Contoh: Jl. WR. Supratman, Kandang Limun Bengkulu" class="w-full border-slate-300 rounded-md text-sm">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-500 uppercase">Ukuran Font</label>
                        <input type="text" name="size_4" value="<?php echo e($kop->size_4 ?? '11px'); ?>" class="w-full border-slate-300 rounded-md text-sm">
                    </div>
                </div>

                <!-- Baris 5 -->
                <div class="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
                    <div class="md:col-span-3">
                        <label class="block text-xs font-semibold text-slate-500 uppercase">Baris 5 (Telepon, Faksimile, Website, Email)</label>
                        <input type="text" name="line_5" value="<?php echo e($kop->line_5 ?? ''); ?>" placeholder="Contoh: Telp: (0736) 21170 Laman: www.unib.ac.id" class="w-full border-slate-300 rounded-md text-sm">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-500 uppercase">Ukuran Font</label>
                        <input type="text" name="size_5" value="<?php echo e($kop->size_5 ?? '11px'); ?>" class="w-full border-slate-300 rounded-md text-sm">
                    </div>
                </div>
            </div>

            <div class="mt-6 text-right">
                <button type="submit" class="px-5 py-2 bg-indigo-600 text-white font-semibold rounded-md shadow hover:bg-indigo-700 text-sm">Simpan Template KOP</button>
            </div>
        </form>
    </div>

</div>     
<?php $__env->stopSection(); ?>
<?php echo $__env->make('asset::layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\aset-app\Modules\Asset\resources\views/master/index.blade.php ENDPATH**/ ?>