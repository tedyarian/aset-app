<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Modules\Asset\Models\BmnItem;
use Illuminate\Support\Facades\File;

class BmnItemSeeder extends Seeder
{
    public function run(): void
    {
        $path = database_path('seeders/aset_bmn.csv');
        if (!File::exists($path)) {
            $path = base_path('aset_bmn.csv');
        }

        if (File::exists($path)) {
            $file = fopen($path, 'r');
            // Deteksi pemisah (delimiter) apakah koma (,) atau titik koma (;)
            $firstLine = fgets($file);
            rewind($file);
            $delimiter = (strpos($firstLine, ';') !== false) ? ';' : ',';

            $isHeader = true;
            $batchData = [];
            $count = 0;

            while (($row = fgetcsv($file, 2000, $delimiter)) !== false) {
                // Lewati baris header di awal
                if ($isHeader) {
                    $isHeader = false;
                    continue;
                }

                if (count($row) < 6) {
                    continue;
                }

                $gol = trim($row[0] ?? '');
                $bid = trim($row[1] ?? '');
                $kel = trim($row[2] ?? '');
                $subKel = trim($row[3] ?? '');
                $subSubKel = trim($row[4] ?? '');
                
                // Ambil uraian/nama barang dari kolom ke-5 (menggabungkan sisa kolom jika terpotong titik koma)
                $nameParts = array_slice($row, 5);
                $name = trim(implode(' ', $nameParts));

                // Abaikan baris kosong atau teks header yang berulang
                if (empty($name) || strtoupper($name) === 'URAIAN' || strtoupper($gol) === 'GOL' || strtoupper($gol) === 'KODE BARANG') {
                    continue;
                }

                // Susun kode lengkap BMN
                $code = sprintf(
                    '%s.%s.%s.%s.%s',
                    $gol !== '' ? $gol : '0',
                    $bid !== '' ? $bid : '0',
                    $kel !== '' ? $kel : '0',
                    $subKel !== '' ? $subKel : '0',
                    $subSubKel !== '' ? $subSubKel : '0'
                );

                $batchData[] = [
                    'gol' => $gol !== '' ? $gol : null,
                    'bid' => $bid !== '' ? $bid : null,
                    'kel' => $kel !== '' ? $kel : null,
                    'sub_kel' => $subKel !== '' ? $subKel : null,
                    'sub_sub_kel' => $subSubKel !== '' ? $subSubKel : null,
                    'code' => $code,
                    'name' => $name,
                    'created_at' => now(),
                    'updated_at' => now(),
                ];

                if (count($batchData) >= 500) {
                    foreach ($batchData as $data) {
                        BmnItem::updateOrCreate(['code' => $data['code']], $data);
                    }
                    $count += count($batchData);
                    $batchData = [];
                }
            }

            fclose($file);

            if (!empty($batchData)) {
                foreach ($batchData as $data) {
                    BmnItem::updateOrCreate(['code' => $data['code']], $data);
                }
                $count += count($batchData);
            }

            echo "Sukses! Total {$count} data BMN berhasil diimpor dengan rapi.\n";
        } else {
            echo "File aset_bmn.csv tidak ditemukan!\n";
        }
    }
}